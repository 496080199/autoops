# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('info', '0020_auto_20151111_1517'),
    ]

    operations = [
        migrations.AddField(
            model_name='configure',
            name='con_status',
            field=models.CharField(max_length=255, null=True, verbose_name=b'\xe9\x85\x8d\xe7\xbd\xae\xe7\x8a\xb6\xe6\x80\x81'),
        ),
        migrations.AlterField(
            model_name='configure',
            name='con_path',
            field=models.CharField(max_length=100, verbose_name=b'\xe9\x85\x8d\xe7\xbd\xae\xe8\xb7\xaf\xe5\xbe\x84'),
        ),
    ]
